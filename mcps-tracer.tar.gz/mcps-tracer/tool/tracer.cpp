#include <unistd.h>

#include <fstream>
#include <iostream>
#include <iomanip> // For std::setfill and std::setw
#include <sstream> // For std::ostringstream

#include "pin.H"
using std::cerr;
using std::endl;
using std::ofstream;
using std::string;

/* ================================================================== */
// Global variables
/* ================================================================== */

INT32 numThreads = 0;

// Force each thread's data to be in its own data cache line so that
// multiple threads do not contend for the same data cache line.
// This avoids the false sharing problem.
// TODO decide if we need padding in this class.
#define PADSIZE 56 // 64 byte line size: 64-8

class thread_data {
  public:
    thread_data(string log_name) {
        ofile.open(log_name.c_str());
        if (!ofile) {
            cerr << "Error: could not open log file: " << log_name << endl;
            exit(1);
        }
        roi = false;
    }

    ~thread_data() { ofile.close(); }

    ofstream ofile;
    bool     roi;
};

// key for accessing TLS storage in the threads. initialized once in main()
static TLS_KEY tls_key = INVALID_TLS_KEY;

/* ===================================================================== */
// Command line switches
/* ===================================================================== */
KNOB<string> KnobOutputFile(KNOB_MODE_WRITEONCE, "pintool", "o",
                            "address_log",
                            "specify file name for the address trace output");

/* ===================================================================== */
// Utilities
/* ===================================================================== */

VOID ThreadStart(THREADID tid, CONTEXT *ctxt, INT32 flags, VOID *v) {
    numThreads++;

    std::ostringstream oss;
    oss << KnobOutputFile.Value() << "." << std::setw(2) << std::setfill('0') << tid;
    std::string file_name = oss.str();
    thread_data *tdata = new thread_data(file_name);
    if (PIN_SetThreadData(tls_key, tdata, tid) == FALSE) {
        cerr << "PIN_SetThreadData failed" << endl;
        PIN_ExitProcess(1);
    }
    cerr << "Started thread with id: " << tid << endl;
}

// This function is called when the thread exits
VOID ThreadFini(THREADID tid, const CONTEXT *ctxt, INT32 code, VOID *v) {
    thread_data *tdata =
        static_cast<thread_data *>(PIN_GetThreadData(tls_key, tid));
    tdata->ofile << "P" << tid << " 0 E 0 0" << endl;

    delete tdata;
    PIN_SetThreadData(tls_key, 0, tid); // Clear entry
    cerr << "Stopped thread with id: " << tid << endl;
}

INT32 Usage() {
    cerr << "This tool traces the memory operations of a multi threaded "
            "program."
         << endl;

    cerr << KNOB_BASE::StringKnobSummary() << endl;

    return -1;
}

/* ===================================================================== */
// Analysis routines
/* ===================================================================== */

// Print a memory read record
VOID RecordMemRead(VOID *ip, VOID *addr, UINT32 size, THREADID tid) {
    thread_data *tdata =
        static_cast<thread_data *>(PIN_GetThreadData(tls_key, tid));
    if (tdata->roi) {
        tdata->ofile << "P" << tid << " " << ip << " R " << addr << " " << size << endl;
    }
}

// Print a memory write record
VOID RecordMemWrite(VOID *ip, VOID *addr, UINT32 size, THREADID tid) {
    thread_data *tdata =
        static_cast<thread_data *>(PIN_GetThreadData(tls_key, tid));
    if (tdata->roi) {
        tdata->ofile << "P" << tid << " " << ip << " W " << addr << " " << size << endl;
    }
}

void set_roi(THREADID tid, bool roi) {
    thread_data *tdata =
        static_cast<thread_data *>(PIN_GetThreadData(tls_key, tid));
    tdata->roi = roi;
}

// The barrier function marker always emits a trace, also outside the roi.
void emit_barrier(THREADID tid) {
    thread_data *tdata =
        static_cast<thread_data *>(PIN_GetThreadData(tls_key, tid));
    tdata->ofile << "P" << tid << " 0 B " << numThreads << " 0" << endl;
}

/* ===================================================================== */
// Instrumentation callbacks
/* ===================================================================== */

// TODO: atomic tracer traces some additional instr cmovs..
// Is called for every instruction and instruments reads and writes
VOID Instruction(INS ins, VOID *v) {
    // Instruments memory accesses using a predicated call, i.e.
    // the instrumentation is called iff the instruction will actually be
    // executed.
    //
    // On the IA-32 and Intel(R) 64 architectures conditional moves and REP
    // prefixed instructions appear as predicated instructions in Pin.
    UINT32 memOperands = INS_MemoryOperandCount(ins);

    // Iterate over each memory operand of the instruction.
    for (UINT32 memOp = 0; memOp < memOperands; memOp++) {
        if (INS_MemoryOperandIsRead(ins, memOp)) {
            INS_InsertPredicatedCall(
                ins, IPOINT_BEFORE, (AFUNPTR)RecordMemRead, IARG_INST_PTR,
                IARG_MEMORYOP_EA, memOp, IARG_MEMORYOP_SIZE, memOp, IARG_THREAD_ID, IARG_END);
        }
        // Note that in some architectures a single memory operand can be
        // both read and written (for instance incl (%eax) on IA-32)
        // In that case we instrument it once for read and once for write.
        if (INS_MemoryOperandIsWritten(ins, memOp)) {
            INS_InsertPredicatedCall(
                ins, IPOINT_BEFORE, (AFUNPTR)RecordMemWrite, IARG_INST_PTR,
                IARG_MEMORYOP_EA, memOp, IARG_MEMORYOP_SIZE, memOp, IARG_THREAD_ID, IARG_END);
        }
    }
}

VOID Image(IMG img, VOID *v) {
    for (SEC sec = IMG_SecHead(img); SEC_Valid(sec); sec = SEC_Next(sec)) {
        for (RTN rtn = SEC_RtnHead(sec); RTN_Valid(rtn);
             rtn = RTN_Next(rtn)) {
            string und_func_name = PIN_UndecorateSymbolName(
                RTN_Name(rtn), UNDECORATION_NAME_ONLY);

            if (und_func_name == "start_roi" ||
                und_func_name == "atomic_trace::start_roi") {
                RTN_Open(rtn);
                cerr << "instrumenting start roi" << endl;
                RTN_InsertCall(rtn, IPOINT_BEFORE, (AFUNPTR)set_roi,
                               IARG_THREAD_ID, IARG_BOOL, true, IARG_END);
                RTN_Close(rtn);
            }
            if (und_func_name == "end_roi" ||
                und_func_name == "atomic_trace::end_roi") {
                RTN_Open(rtn);
                cerr << "instrumenting stop roi" << endl;
                RTN_InsertCall(rtn, IPOINT_BEFORE, (AFUNPTR)set_roi,
                               IARG_THREAD_ID, IARG_BOOL, false, IARG_END);
                RTN_Close(rtn);
            }
            if (und_func_name == "barrier" ||
                und_func_name == "atomic_trace::barrier") {
                RTN_Open(rtn);
                cerr << "adding barrier" << endl;
                RTN_InsertCall(rtn, IPOINT_BEFORE, (AFUNPTR)emit_barrier,
                               IARG_THREAD_ID, IARG_END);
                RTN_Close(rtn);
            }
        }
    }
}

VOID Fini(INT32 code, VOID *v) {}

int main(int argc, char *argv[]) {
    PIN_InitSymbols();
    if (PIN_Init(argc, argv)) {
        return Usage();
    }

    string fileName = KnobOutputFile.Value();

    // Obtain a key for TLS storage.
    tls_key = PIN_CreateThreadDataKey(NULL);
    if (tls_key == INVALID_TLS_KEY) {
        cerr << "number of already allocated keys reached the "
                "MAX_CLIENT_TLS_KEYS limit"
             << endl;
        PIN_ExitProcess(1);
    }

    // Register ThreadStart to be called when a thread starts.
    PIN_AddThreadStartFunction(ThreadStart, NULL);

    // Register Fini to be called when thread exits.
    PIN_AddThreadFiniFunction(ThreadFini, NULL);

    // Register Fini to be called when the application exits.
    PIN_AddFiniFunction(Fini, NULL);

    // Register function to be called to instrument instructions.
    IMG_AddInstrumentFunction(Image, 0);
    INS_AddInstrumentFunction(Instruction, 0);

    cerr << "===============================================" << endl;
    cerr << "This application is instrumented by the MCPS tracer tool" << endl;
    if (!KnobOutputFile.Value().empty()) {
        cerr << "See thread logs " << KnobOutputFile.Value()
             << " for analysis results" << endl;
    }
    cerr << "===============================================" << endl;

    // Start the program, never returns
    PIN_StartProgram();

    return 0;
}
