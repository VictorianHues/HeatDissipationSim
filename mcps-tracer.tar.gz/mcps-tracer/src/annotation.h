#ifndef _ANNOTATION_H
#define _ANNOTATION_H

// provide annotation for persistent memory traces
// need general trace annotation (threads, region of interest)
// persistent memory regions (pers_malloc)
// and persist barriers

#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
namespace atomic_trace {
void start_roi();
void end_roi();
void barrier();
} // namespace atomic_trace

extern "C" {
// C version
void start_roi();
void end_roi();
void barrier();
}
#else
// C version
void start_roi();
void end_roi();
void barrier();
#endif

#endif // end ifndef
