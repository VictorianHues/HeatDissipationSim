# Requirements

## Intel Pin kit

Download the intel Pin kit from Canvas or from [Intel](https://www.intel.com/content/www/us/en/developer/articles/tool/pin-a-binary-instrumentation-tool-downloads.html).  Unpack the `tar` file and set PIN_ROOT to the installation location, eg:

```
export PIN_ROOT=/path/to/pintool/pin-3.xx
```

Also add the installation directory to your `PATH` with:

```
export PATH+=:/path/to/pintool/pin-3.xx
```

# Installation

Once the intel Pin kit is installed you can compile the address tracer with:

```
~/mcps-tracer$ make
```

The make command compiles the address tracer and the annotation library. You can use the annotation library to set the region of interest (roi) in the program that you want to trace. The address tracer will only trace the code that is between the `start_roi()` and `end_roi()` function calls.

# Create an address trace

We provide a couple of example programs with annotations that you can trace.  Compile the `simple_add_openmp` example program:

```
~/mcps-tracer$ cd examples
~/mcps-tracer/examples$ make simple_add_openmp
```

Now you can trace the address accesses of the `simple_add_openmp` binary with:

```
~/mcps-tracer$ pin -t tool/obj-intel64/tracer.so -- examples/simple_add_openmp
```

The tracer generates ascii trace files, one for every thread in the program.  The thread id is added as a suffix.  The default output file name is `address_log`. Since the `simple_add_openmp` has four threads the tracer generates four files: `address_log.00, address_log.01, address_log.02, address_log.03`.  You can specify a different output basename with the `-o` flag.

The `trace_convertor.py` script converts the ascii address traces of the all threads to a single the binary `trf` trace file:

```
~/mcps-tracer$ scripts/trace_converter.py address_log simple_add_trace.trf
```

The resulting `simple_add_trace.trf` trace file can now be used as input for the cache simulator in the MCPS course. The trace converter filters out memory operations that are not 4-byte aligned.  You can disable trace filtering with the `-d` flag.
