#include "annotation.h"

void atomic_trace::start_roi() {}
void atomic_trace::end_roi() {}
void atomic_trace::barrier() {}

extern "C" {
    void start_roi() {};
    void end_roi() {};
    void barrier() {};
}
